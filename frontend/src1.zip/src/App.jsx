import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";

import Header from "./component/Header/Header.jsx";
import Navbar from "./component/Navbaar/Navbar.jsx";
import Footer from "./component/Footer/Footer.jsx";


// Pages
import Home from "./Pages/Home/Home.jsx";
import About from "./pages/About/About.jsx";
import ExpertEditorialSupport from "./Pages/ExpertEditorialSupport/ExpertEditorialSupport.jsx";
import SubmitManuscript from "./Pages/SubmitManuscript/SubmitManuscript.jsx";
import Archives from "./Pages/Archives/Archives.jsx";
import Researcher from "./Pages/Researcher/Researcher.jsx";
import Contact from "./Pages/Contact/Contact.jsx";

// Popups
import LoginPopup from "./Pages/Login/Login.jsx";
import RegisterPopup from "./Pages/Register/Register.jsx";
import ForgotPasswordPopup from "./Pages/ForgotPassword/ForgotPassword.jsx"; // ✅ ADD

function App() {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isForgotOpen, setIsForgotOpen] = useState(false); // ✅ ADD

  return (
    <Router>
      <div className="App">
        <Header />

        <Navbar
          onLoginClick={() => {
            setIsRegisterOpen(false);
            setIsForgotOpen(false);
            setIsLoginOpen(true);
          }}
          onRegisterClick={() => {
            setIsLoginOpen(false);
            setIsForgotOpen(false);
            setIsRegisterOpen(true);
          }}
        />

        <LoginPopup
          isOpen={isLoginOpen}
          onClose={() => setIsLoginOpen(false)}
          onRegisterClick={() => {
            setIsLoginOpen(false);
            setIsRegisterOpen(true);
          }}
          onForgotPasswordClick={() => {
            setIsLoginOpen(false);
            setIsForgotOpen(true);
          }}
        />

        <ForgotPasswordPopup
          isOpen={isForgotOpen}
          onClose={() => setIsForgotOpen(false)}
        />

        <RegisterPopup
          isOpen={isRegisterOpen}
          onClose={() => setIsRegisterOpen(false)}
        />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route
            path="/expert-editorial-support"
            element={<ExpertEditorialSupport />}
          />
          <Route path="/submit-manuscript" element={<SubmitManuscript />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/researcher" element={<Researcher />} />
          <Route path="/contact" element={<Contact />} />

        </Routes>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
