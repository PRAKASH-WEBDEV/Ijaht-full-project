import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div>
          <h4>About GJMR</h4>
          <p>The Global Journal of Medical Research is a leading open-access publisher serving the academic community since 2010.</p>
        </div>
        <div>
          <h4>Resources</h4>
          <a href="#apc">Article Processing Charges</a>
          <a href="#policy">Open Access Policy</a>
          <a href="#reviewer">Reviewer Guidelines</a>
        </div>
        <div>
          <h4>Contact Info</h4>
          <p>Email: contact@gjmr-journal.org</p>
          <p>Medical Plaza Tower, NY, USA</p>
        </div>
      </div>
      <div className="footer-bottom">
        &copy; 2025 Global Journal of Medical Research. All Rights Reserved.
      </div>
    </footer>
  );
};

export default Footer;