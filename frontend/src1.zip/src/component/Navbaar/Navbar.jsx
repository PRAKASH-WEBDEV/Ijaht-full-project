import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./Navbar.css";

const Navbar = ({ onLoginClick, onRegisterClick }) => {

    const [showMenu, setShowMenu] = useState(false);

  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.reload(); // simple + reliable
  };

  return (
    <nav className="main-nav">
      <div className="nav-links">
        <NavLink
          to="/"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Home
        </NavLink>

        <NavLink
          to="/about"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          About
        </NavLink>

        <NavLink
          to="/expert-editorial-support"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Expert Editorial Support
        </NavLink>

        <NavLink
          to="/submit-manuscript"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Submit Manuscript
        </NavLink>

        <NavLink
          to="/archives"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Archives
        </NavLink>

        <NavLink
          to="/researcher"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Researcher
        </NavLink>

        <NavLink
          to="/contact"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          Contact
        </NavLink>
      </div>

      <div className="auth-buttons">
        {!user ? (
          <>
            <button className="login-btn" onClick={onLoginClick}>
              Log In
            </button>
            <button className="register-btn" onClick={onRegisterClick}>
              Register
            </button>
          </>
        ) : (
          <div className="profile-wrapper">
            <div
              className="profile-icon"
              onClick={() => setShowMenu(!showMenu)}
            >
              👤
            </div>

            {showMenu && (
              <div className="profile-dropdown">
                <p className="profile-name">{user.name}</p>
                <button onClick={logout} className="logout-btn">
                  Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
