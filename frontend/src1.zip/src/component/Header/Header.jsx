import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="main-header">
      <div className="logo-area">
        <h1>International journal of applied healthcare and technology</h1>
        <p>ISSN (Online): 2456-123X | Peer-Reviewed Open Access</p>
      </div>
      <div className="search">
        <input type="text" placeholder="Search articles, DOI, authors..." />
      </div>
    </header>
  );
};

export default Header;