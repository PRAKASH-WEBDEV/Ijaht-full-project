import React from 'react';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="sidebar-box">
        <h4>Journal Metrics</h4>
        <p><strong>Impact Factor:</strong> 3.25 (2024)</p>
        <p><strong>CiteScore:</strong> 4.1</p>
        <p><strong>H-Index:</strong> 112</p>
        <p><strong>Avg. Review Time:</strong> 18 Days</p>
      </div>

      <div className="sidebar-box">
        <h4>For Authors</h4>
        <ul>
          <li><a href="#guidelines">Author Guidelines</a></li>
          <li><a href="#fees">Publication Fees</a></li>
          <li><a href="#ethics">Ethics & Policies</a></li>
          <li><a href="#status">Check Manuscript Status</a></li>
        </ul>
      </div>

      <div className="sidebar-box newsletter-box">
        <h4>Newsletter</h4>
        <p>Get the latest research delivered to your inbox.</p>
        <input type="email" placeholder="Your Email" />
        <button>Subscribe</button>
      </div>
    </aside>
  );
};

export default Sidebar;