import React from 'react';
import './Home.css';
import Sidebar from "../../component/Sidebar/Sidebar";



const Home = () => (
  <>
    <section className="hero">
      <div className="hero-text">
        <h2>Advancing Healthcare Through Scholarly Excellence</h2>
        <p>Join a global community of researchers and clinicians. We provide a high-impact platform for your breakthroughs in medical science.</p>
        <div className="cta-buttons">
          <a href="#submit" className="btn btn-primary">Submit Your Manuscript</a>
          <a href="#browse" className="btn btn-secondary">Browse Current Issue</a>
        </div>
      </div>
    </section>

    <div className="main-container">
      <div className="content-area">
        <h3 className="section-title">Latest Articles</h3>
        <ArticleCard 
          tag="Original Research" 
          title="Comparison of Robotic-Assisted vs Manual Knee Arthroplasty: A 5-Year Study"
          authors="Dr. Sameer Khan, Dr. Elena Rodriguez, et al."
          doi="10.555/gjmr.2025.042"
        />
        {/* Aur Articles yaha add kar sakte hain */}
      </div>
      <Sidebar />
    </div>
  </>
);

// ArticleCard Sub-component
const ArticleCard = ({ tag, title, authors, doi }) => (
  <div className="article-card">
    <span className="article-tag">{tag}</span>
    <div className="article-title">{title}</div>
    <div className="authors">{authors}</div>
    <div className="article-meta">Published: Dec 2025 | DOI: {doi}</div>
  </div>
);

export default Home;