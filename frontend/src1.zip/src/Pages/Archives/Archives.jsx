import React from 'react';
import './Archives.css';

const Archives = () => {
  // Sample Data: Real project mein ye API se aayega
  const archiveData = [
    {
      year: "2025",
      volumes: [
        { vol: "Volume 15", issue: "Issue 2 (Current)", date: "Dec 2025", count: 12 },
        { vol: "Volume 15", issue: "Issue 1", date: "June 2025", count: 15 }
      ]
    },
    {
      year: "2024",
      volumes: [
        { vol: "Volume 14", issue: "Issue 2", date: "Dec 2024", count: 18 },
        { vol: "Volume 14", issue: "Issue 1", date: "June 2024", count: 14 }
      ]
    },
    {
      year: "2023",
      volumes: [
        { vol: "Volume 13", issue: "Issue 1 & 2", date: "Full Year", count: 28 }
      ]
    }
  ];

  return (
    <div className="archives-container">
      {/* Page Header */}
      <header className="page-header">
        <h1>Archives</h1>
        <p className="breadcrumb">Home / Archives</p>
      </header>

      <section className="archives-intro">
        <div className="section-title">
          <span className="blue-bar"></span>
          <h2>Past Publications</h2>
        </div>
        <p>Aap niche diye gaye years ke hisaab se hamare saare pichle volumes aur issues ko access kar sakte hain.</p>
      </section>

      <div className="archives-list">
        {archiveData.map((item, index) => (
          <div key={index} className="year-section">
            <h3 className="year-heading">{item.year}</h3>
            <div className="volumes-grid">
              {item.volumes.map((vol, i) => (
                <div key={i} className="archive-card">
                  <div className="card-left">
                    <span className="folder-icon">📂</span>
                  </div>
                  <div className="card-right">
                    <h4>{vol.vol}</h4>
                    <p className="issue-name">{vol.issue}</p>
                    <p className="issue-meta">{vol.date} • {vol.count} Articles</p>
                    <button className="view-btn">View Issue</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Archives;