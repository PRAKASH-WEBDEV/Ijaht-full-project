import React, { useState } from "react";
import "./SubmitManuscript.css";
import axios from "axios";

const SubmitManuscript = () => {
  const [formData, setFormData] = useState({
    title: "",
    abstract: "",
    authorName: "",
    email: "",
    manuscriptFile: null,
  });

  // Custom Alert State
  const [alert, setAlert] = useState({ show: false, message: "", type: "" });

  const showAlert = (msg, type = "error") => {
    setAlert({ show: true, message: msg, type: type });
    // 4 second baad automatic alert band karne ke liye
    setTimeout(() => setAlert({ show: false, message: "", type: "" }), 4000);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, manuscriptFile: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userToken = localStorage.getItem("token");
    
    if (!userToken) {
      showAlert("Login Required! Please sign in to submit your work.", "warning");
      return;
    }

    if (!formData.manuscriptFile) {
      showAlert("Missing File: Please upload your manuscript PDF/Docx.", "error");
      return;
    }

    try {
      const data = new FormData();
      data.append("articleTitle", formData.title);
      data.append("authorName", formData.authorName);
      data.append("email", formData.email);
      data.append("abstract", formData.abstract);
      data.append("manuscript", formData.manuscriptFile);

      // API Call
      const response = await axios.post("http://localhost:3000/api/manuscript/submit", data, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": `Bearer ${userToken}`
        },
      });

      // ✅ SUCCESS ACTION
      if (response.status === 201 || response.status === 200) {
        showAlert("Success! Your manuscript has been submitted for review.", "success");

        // 1. Details gayab karo (Reset State)
        setFormData({
          title: "",
          abstract: "",
          authorName: "",
          email: "",
          manuscriptFile: null,
        });

        // 2. Page reload karo 2 second baad taaki user alert dekh sake
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }

    } catch (error) {
      console.error("Submission error:", error);
      // Agar backend 500 error de raha hai toh yahan check hoga
      showAlert("Submission Failed! Please check your connection or Email settings.", "error");
    }
  };

  return (
    <div className="submit-container">
      {/* --- CUSTOM DESIGNED ALERT --- */}
      {alert.show && (
        <div className={`custom-alert ${alert.type}`}>
          <div className="alert-content">
            <span className="alert-icon">
              {alert.type === "success" ? "✅" : alert.type === "warning" ? "⚠️" : "❌"}
            </span>
            <p>{alert.message}</p>
            <button className="alert-close" onClick={() => setAlert({ show: false })}>×</button>
          </div>
          <div className="alert-progress"></div>
        </div>
      )}

      <header className="page-header">
        <h1>Submit Manuscript</h1>
        <p className="breadcrumb">Home / Submit Manuscript</p>
      </header>

      <div className="submit-content">
        <div className="form-section">
          <div className="section-title">
            <span className="blue-bar"></span>
            <h2>Manuscript Details</h2>
          </div>

          <form className="manuscript-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Article Title *</label>
              <input type="text" name="title" value={formData.title} placeholder="Enter title" required onChange={handleChange} />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Author Name *</label>
                <input type="text" name="authorName" value={formData.authorName} required onChange={handleChange} />
              </div>
              <div className="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" value={formData.email} required onChange={handleChange} />
              </div>
            </div>

            <div className="form-group">
              <label>Abstract *</label>
              <textarea rows="5" name="abstract" value={formData.abstract} required onChange={handleChange}></textarea>
            </div>

            <div className="form-group">
              <label>Upload Manuscript (PDF/Docx) *</label>
              <div className="file-upload-box">
                <input type="file" id="fileInput" accept=".pdf,.doc,.docx" hidden onChange={handleFileChange} />
                <label htmlFor="fileInput" className="upload-label">
                  <span className="upload-icon">📁</span>
                  {formData.manuscriptFile ? formData.manuscriptFile.name : "Choose File"}
                </label>
              </div>
            </div>

            <button type="submit" className="submit-btn">Submit for Review</button>
          </form>
        </div>

        <aside className="guidelines-sidebar">
          <div className="guidelines-card">
            <h3>Guidelines</h3>
            <ul>
              <li>Plagiarism below 15%</li>
              <li>IEEE/APA Style</li>
              <li>Only PDF or Docx formats</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default SubmitManuscript;