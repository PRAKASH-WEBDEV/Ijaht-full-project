import React from 'react';
import './ExpertEditorial.css';

const ExpertEditorialSupport = () => {
  return (
    <div className="editorial-container">
      {/* Page Header */}
      <header className="page-header">
        <h1>Expert Editorial Support</h1>
        <p className="breadcrumb">Home / Expert Editorial Support</p>
      </header>

      {/* Intro Section */}
      <section className="intro-section">
        <div className="section-title">
          <span className="blue-bar"></span>
          <h2>Editorial Excellence</h2>
        </div>
        <p className="intro-text">
          Hamara journal authors ko world-class editorial support provide karta hai. 
          Hum research papers ki quality aur clarity ko enhance karne ke liye industry 
          experts ke saath collaborate karte hain taaki aapka work global standards ko meet kare.
        </p>
      </section>

      {/* Services Cards */}
      <div className="services-grid">
        <div className="service-card">
          <h3>Peer Review Management</h3>
          <p>Double-blind peer review process ko manage karna taaki unbiased feedback mil sake.</p>
        </div>
        <div className="service-card">
          <h3>Copyediting & Formatting</h3>
          <p>Technical accuracy aur grammatical precision ke liye comprehensive editing services.</p>
        </div>
        <div className="service-card">
          <h3>Ethical Validation</h3>
          <p>COPE guidelines ke hisaab se research ethics aur plagiarism checks ensure karna.</p>
        </div>
      </div>

      {/* Process Section */}
      <section className="process-section">
        <div className="section-title">
          <span className="blue-bar"></span>
          <h2>Our Editorial Process</h2>
        </div>
        <div className="process-steps">
          <div className="step">
            <div className="step-num">01</div>
            <h4>Initial Screening</h4>
            <p>Manuscript ki scope aur technical standards ki basic check-up.</p>
          </div>
          <div className="step">
            <div className="step-num">02</div>
            <h4>Expert Review</h4>
            <p>Subject matter experts dwara detailed analysis aur feedback.</p>
          </div>
          <div className="step">
            <div className="step-num">03</div>
            <h4>Final Approval</h4>
            <p>Quality check ke baad journal publication ke liye finalize karna.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ExpertEditorialSupport;