import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="about-page">
      {/* Breadcrumb Section */}
      <div className="page-header">
        <div className="container">
          <h2>About the Journal</h2>
          <p>Home / About Us</p>
        </div>
      </div>

      <section className="about-content container">
        <div className="about-main">
          <h3>Our Mission & Vision</h3>
          <p>
            The <strong>Global Journal of Medical Research (GJMR)</strong> is an international, 
            peer-reviewed, open-access journal dedicated to the rapid dissemination of high-quality 
            research in the field of medical sciences. Founded in 2010, our mission is to bridge 
            the gap between clinical practice and academic research.
          </p>
          
          <div className="mission-grid">
            <div className="mission-item">
              <h4>Integrity</h4>
              <p>Maintaining the highest standards of double-blind peer review.</p>
            </div>
            <div className="mission-item">
              <h4>Accessibility</h4>
              <p>Providing free access to medical breakthroughs for clinicians worldwide.</p>
            </div>
            <div className="mission-item">
              <h4>Innovation</h4>
              <p>Supporting the latest advancements in AI and Robotic medicine.</p>
            </div>
          </div>

          <h3>Journal History</h3>
          <p>
            Over the past 15 years, GJMR has evolved from a small quarterly publication to a 
            monthly leading authority in medical research. We have published over 5,000 articles 
            from researchers in 85+ countries, maintaining a steady impact factor growth.
          </p>
        </div>

        {/* Team Section */}
        <div className="team-section">
          <h3>Meet Our Leadership</h3>
          <div className="team-grid">
            <div className="team-card">
              <div className="avatar">DR</div>
              <h5>Dr. Robert Harrison</h5>
              <p>Editor-in-Chief</p>
              <span>Johns Hopkins University, USA</span>
            </div>
            <div className="team-card">
              <div className="avatar">SL</div>
              <h5>Prof. Sarah Lin</h5>
              <p>Managing Editor</p>
              <span>National University of Singapore</span>
            </div>
            <div className="team-card">
              <div className="avatar">MA</div>
              <h5>Dr. Marcus Aurelius</h5>
              <p>Senior Reviewer</p>
              <span>King's College London, UK</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;