import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <div className="contact-container">
      {/* Page Header */}
      <header className="page-header">
        <h1>Contact Us</h1>
        <p className="breadcrumb">Home / Contact</p>
      </header>

      <div className="contact-grid">
        {/* Left Side: Contact Information */}
        <div className="contact-info">
          <div className="section-title">
            <span className="blue-bar"></span>
            <h2>Get In Touch</h2>
          </div>
          <p className="contact-desc">
            Hamari team aapki queries ka jawab dene ke liye hamesha taiyar hai. 
            Niche diye gaye details ke zariye aap humse sampark kar sakte hain.
          </p>

          <div className="info-cards">
            <div className="info-item">
              <span className="info-icon">📍</span>
              <div>
                <h4>Our Address</h4>
                <p>123 Medical Research Plaza, Sector 45, New Delhi, India - 110001</p>
              </div>
            </div>

            <div className="info-item">
              <span className="info-icon">📧</span>
              <div>
                <h4>Email Support</h4>
                <p>editor@appliedhealthcare.com<br/>support@appliedhealthcare.com</p>
              </div>
            </div>

            <div className="info-item">
              <span className="info-icon">📞</span>
              <div>
                <h4>Call Us</h4>
                <p>+91 98765 43210<br/>Mon - Fri: 9:00 AM - 6:00 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Message Form */}
        <div className="contact-form-card">
          <h3>Send a Message</h3>
          <form className="contact-form">
            <div className="form-group">
              <input type="text" placeholder="Your Full Name" required />
            </div>
            <div className="form-group">
              <input type="email" placeholder="Email Address" required />
            </div>
            <div className="form-group">
              <input type="text" placeholder="Subject" />
            </div>
            <div className="form-group">
              <textarea rows="5" placeholder="Your Message or Query..."></textarea>
            </div>
            <button type="submit" className="send-btn">Send Message</button>
          </form>
        </div>
      </div>

      {/* Map Section Placeholder */}
      <div className="map-section">
        <div className="map-placeholder">
          {/* Aap yahan Google Maps iframe daal sakte hain */}
          <p>📍 Google Maps Will Be Rendered Here</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;